<div style="background-color:rgb(100, 255, 100, 0.25); text-align:center; padding:20px">
<p> 
Homework 13 [TI8419 - Multilinear Algebra]

Lucas Abdalah

Professors: André Lima e Henrique Goulart

</p> 
</div>

- - - 

# Table of Contents
- [Tensor Train Singular Value Decomposition (TT-SVD)](#tensor-train-singular-value-decomposition-tt-svd)
  - [Problem 1](#problem-1)
  - [Problem 2](#problem-2)

# Tensor Train Singular Value Decomposition (TT-SVD)

## Problem 1

---

### Results

<!--  -->

## Problem 2

---

### Results

<!--  -->
