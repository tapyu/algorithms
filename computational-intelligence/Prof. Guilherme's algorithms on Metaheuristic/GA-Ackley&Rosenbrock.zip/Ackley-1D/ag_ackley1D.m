% Implementacao de um AG real para encontrar o minimo da
% funcao de Ackely 1-D
%
%  f(x) = -20*exp(-0.2*|x|)-exp(cos(2*pi*x)) + 20 + exp(1), -5<=x<=5.
%
% Autor: Guilherme A. Barreto
% Data: 10/09/2020

clear; clc; close all;

%%% Parametros do AG
N=30;    % Tamanho da populacao
p=1;    % Tamanho do cromossomo (no. de genes)
pc=0.90;    % Probabilidade de cruzamento
pm=0.005; % Probabilidade de mutacao
Ng=30;   % Numero de geracoes

%%% Grafico da funcao a ser minimizada
xx=-5:0.1:5;
yy=avaliapop2(xx');

%%% Geracao da populacao inicial
xl=-5;  xu=5;   % limites inferior/superior do espaco de busca 
X=unifrnd(xl,xu,N,p);

%%% Avaliacao da populacao inicial
F=avaliapop2(X);  % Retorna a aptidao de cada individuo da populacao

figure; plot(xx,yy,'k-','linewidth',2,X,F,'*g','markersize',10); 
xlabel('X'); ylabel('F(X)'); grid; axis([-5 5 0 15]);
set(gca, "fontsize", 14) 


%%% Roda AG por Ng geracoes
limits=[xl xu];
for t=1:Ng,
    geracao=t,
    S=selecao_torneio(X,F);
    X=cruzamento2(X,S,pc,limits);
    X=mutacao2(X,pm,limits);
    F=avaliapop2(X);
    
    [Fbest Ibest]=min(F);  % problema eh minimizacao
    [Fworst Iworst]=max(F);  
    
    solucao_best(t)=X(Ibest,:);
    solucao_worst(t)=X(Iworst,:);
    aptidao_best(t)=Fbest;
    aptidao_worst(t)=Fworst;
    
    if !mod(t,5),
      figure; plot(xx,yy,'k-','linewidth',2,X,F,'*g','markersize',10,solucao_best(t),aptidao_best(t),'ro','linewidth',3,'markersize',10);
      xlabel('X'); ylabel('F(X)'); grid; axis([-5 5 0 15]); set(gca, "fontsize", 14) 
    end
    pause
end

RESULTS=[solucao_best(end) aptidao_best(end)]

figure; 
plot(1:Ng,aptidao_best,'b-','linewidth',3,1:Ng,aptidao_worst,'r-','linewidth',3);
xlabel('Geracao'); ylabel('APTIDAO'); grid; axis([0 30 0 15]);
h = legend('Melhor solucao','Pior solucao');
set(h, "fontsize", 14);
set(gca, "fontsize", 14);