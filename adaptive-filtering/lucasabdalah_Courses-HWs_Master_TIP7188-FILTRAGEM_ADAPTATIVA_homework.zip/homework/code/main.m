%% Função Main
% [TIP7188 - Filtragem Adaptativa]
% Author: Lucas Abdalah
%
%
% main.m

clearvars;
close all;
clc; pause(0.1)

% publish('main.m', 'pdf');
% publish('filter_hw.m', 'pdf');

% filter_hw.hw2p5();
% filter_hw.hw3p4();
% filter_hw.hw3p5();
% filter_hw.hw3p6();
% filter_hw.hw4p1();
% filter_hw.hw4p3();