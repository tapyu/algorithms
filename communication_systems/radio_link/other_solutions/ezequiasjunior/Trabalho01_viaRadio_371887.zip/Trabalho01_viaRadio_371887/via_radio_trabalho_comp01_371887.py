#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import pandas as pd

# Obtenção de dados do arquivo "tabela_radio.csv" 
# que contem os pares distância-altura (x,y):
df = pd.read_csv('tabela_radio.csv')
x = np.array(df['x(km)'])
y = np.array(df['h(m)'])

# Para uso com os dados do radio mobile disponibilizados
# Descomentar abaixo:
# x = np.load('dist_iguatemi_farol.npy')
# y = np.load('alturas_iguatemi_farol.npy')

# Definindo x e y manualmente: x = [d1,d2,d3,...,dn]
# Descomentar abaixo:
# x = [] #
# y = [] #
# x = np.array(x)
# y = np.array(x)

# Valores parâmetros para construção do perfil:
k = 4/3      # Fator de raio efetivo da terra
f = 5        # Freqência de operação do enlace em GHz  
htx = 30     # Altura da base transmissora em m
hrx = 30     # Altura da base receptora em m

# Valores utilizados para o cálculo das curvas parabólicas 
#e da correção do perfil:
hmax = max(y)         # Altura máxima ao longo do enlace [m]
hmin = 450            # Altura mínima ao longo do enlace [m]
dist = x[-1] - x[0]   # Distância do enlace [km]
R = k * 6371          # Raio da terra corrigido [km]

print(f'''Dados do enlace:
Frequência: {f} GHz
Distância: {dist} km
Alturas tx, rx: {htx} m, {hrx} m
''')

print(f'''Valores de distância do enlace [km]: 
{x}

Valores de alturas ao longo do enlace [m]: 
{y}
''')

# Distância entre as curvas parabólicas dh: 10% da altura máxima
dh = int(0.1 * hmax)
# Número de curvas:
m = 1 + (hmax - hmin)/dh
# Incremento das curvas:
dy = dh*np.arange(m) + hmin

print(f'''Dados do cálculo do perfil:
Espaçamento entre as curvas: {dh}
Número de curvas: {np.ceil(m)}
Alturas das curvas: 
{dy}
Raio da terra corrigido: {R} km
''')

# Cálculo do vetor de alturas corrigido:
yaux = (-x**2 + x*dist)/(2*R*1e-3)

print(f'''Valores da curva no nível do mar h=0m:
{yaux}
''')

# Cálculo da matrix de curvas parabólicas:
curvas = np.zeros((dy.size, x.size))
for i in range(dy.size): 
    curvas[i, :] = (yaux) + dy[i] 

# Perfil topográfico : alturas corrigidas [km]: 
Y = yaux + y

print(f'''Valores de altura corrigidos:
{Y}''')

# Linha de Visada e Zona de Fresnel:
# Linha de visada:
Lv = htx + Y[0] + x*(Y[-1] + hrx - Y[0] - htx)/dist

# Raios da primeira zona de Fresnel:
fr1 = 17.3*np.sqrt(x*(dist - x)/(f*dist))

# Zonas de Fresnel superio:
fa = Lv + fr1
fb = Lv - fr1

# Plotagem dos resultados:
plt.style.use('default')
for i in range(dy.size):
    mpl.rcParams['lines.linewidth'] = 0.85
    plt.plot(x, curvas[i, :], 'xkcd:grey')
#     plt.plot(x, yaux, 'xkcd:grey')

plt.grid(axis='x')
# plt.xticks(np.arange(0, x[-1], (x[1]-x[0])*10))
plt.plot(x, Y, label='Perfil corrigido')
plt.plot(x, Lv, 'k-', label='Linha de visada')
plt.plot(x, fa, 'r-.', label='Zona de Fresnel')
plt.plot(x, fb, 'r-.')
plt.legend()
# Salvando figura de saída:
plt.savefig('perfil_topografico_371887')
plt.show()

