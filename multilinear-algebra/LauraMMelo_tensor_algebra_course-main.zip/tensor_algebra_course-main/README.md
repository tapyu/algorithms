# tensor_algebra_course
Implementations, homeworks and exercises made by me during the Tensor Algebra Course given at the Universidade Federal do Ceará (UFC) in 2020.2, from the Teleinformatics Engineering Post-Graduate Program.
