clear; clc; 

X=load('dataset1.dat');

Kmax=10;
Nrep=20;   % Num. max. de replicacoes do Kmedias
MaxIter=20;  % Num. max. de iteracoes em cada replicacao

m=mean(X);  % Centroide do conjunto de dados
[N p]=size(X);  % Dimensao da matriz de dados

for k=2:Kmax,
    disp('Numero de clusters igual a'), disp(k), disp('');
    [IDX, CENTERS] = kmeans(X,k,'DISTANCE','sqeuclidean','REPLICATES',Nrep,'MAXITER',MaxIter);
    %[IDX, CENTERS] = kmeans(X,k,'DISTANCE','cosine','REPLICATES',Nrep,'MAXITER',MaxIter);
    
    Sb=zeros(p);  % Matriz de espalhamento entregrupos(interclusters)
    Sw=zeros(p);  % Matriz de espalhamento intragrupos(intraclusters)
    for i=1:k,
      %i,
      I=find(IDX==i);  % Indices das linhas com vetores atribuidos ao cluster "i"
      Ni=length(I);  % Num. itens no cluster i
      Xi=X(I,:); % Particao associada ao centroide "i"
      Sw=Sw+Ni*cov(Xi);  % Matriz de espalhamento intragrupos (within group)
      vi=CENTERS(i,:)-m; % vetor auxiliar para o proximo calculo
      Sb=Sb+Ni*vi'*vi; % Matriz de espalhamento entregrupos (between groups)
    endfor
    
    num = trace(Sb)/(k-1);
    den = trace(Sw)/(N-k);
    
    CH(k) = num/den;
end

[CHmax Imax]=max(CH)

figure; plot(2:Kmax,CH(2:Kmax),'b-','linewidth',2');
xlabel('Numero de clusters');
ylabel('Indice CH'); grid 
title('Validacao pelo indice Calinski-Harabasz');
set(gca, "fontsize", 14);