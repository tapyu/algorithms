% Implementacao do algoritmo K-medias sequencial
%
% Autor: Guilherme Barreto
% Data: 20/11/2018 
%
clear; clc; close all;

X=load('dataset1.dat'); % Leitura do conjunto de dados
[N M]=size(X);

K=1;  % Numero de prototipos escolhido

% Posicao inicial dos prototipos
I=randperm(N,K); W=X(I,:);   % Seleciona aleatoriamente K exemplos do conjunto de dados 
W=zeros(K,2);  % Inicia prototipos com zero.


figure; 
plot(X(:,1),X(:,2),'g+','markersize',10,'linewidth',3,W(:,1),W(:,2),'b*','markersize',12,'linewidth',4); grid
set(gca, "fontsize", 14); hold on

Ne=200;   % Numero de iteracoes
lr=0.01;  % Passo de aprendizagem

for r=1:Ne,

  % Embaralha conjunto de dados a cada epoca de treinamento
  I=randperm(N); X=X(I,:);
  
  % Busca pelo prototipo mais proximo do vetor de atributos atual
  soma=0;
  for t=1:N,
    for i=1:K,
      Dist2(i)=norm(X(t,:)-W(i,:));
    end
    [dummy Istar]=min(Dist2);   % Indice do prototipo mais proximo
    
    aux=X(t,:)-W(Istar,:);
    soma=soma+aux*aux';     % Usado no calculo do SSD por epoca

    % Atualiza posicao do prototipo mais proximo
    W(Istar,:) = W(Istar,:) + lr*aux;
  end
  
  SSD(r)=soma;
  
end

% Mostra posicao final dos prototipos 
plot(X(:,1),X(:,2),'g+','markersize',10,'linewidth',3,W(:,1),W(:,2),'ro','markersize',12,'linewidth',4);
%voronoi(W(:,1),W(:,2)); 
set(gca, "fontsize", 14);
hold off


% Mostra evolucao do SSD ao longo das epocas de treinamento
figure; plot(SSD,'linewidth',3); grid
xlabel('Epocas de treinamento');
ylabel('SSD'); title('SSD por epoca de treinamento')
set(gca, "fontsize", 14);

% Realiza particao pos-treinamento do conjunto original em K subconjuntos
for t=1:N,
    for i=1:K,
      Dist2(i)=norm(X(t,:)-W(i,:));
    end
    [dummy Istar]=min(Dist2);   % Indice do prototipo mais proximo
    
    Icluster(t)=Istar; 
end

for k=1:K,
    I=find(Icluster==k); % Indice de todos os exemplos mais proximos do prototipo W_k
    Particao{k}=X(I,:);  % Separa todos os exemplos da k-esima particao
end

SSD(end)


