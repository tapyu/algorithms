function Xnew=cruzamento3(X,S,Pc,limits);

% Cruzamento por 1 ponto de corte
% 
% Variaveis de entrada
% ====================
% P: populacao atual
% S: pares selecionados para POTENCIAL geracao de prole (cruzamento)
% Pc: probabilidade de recombinacao (crossover)
%
%
% Variaveis de saida
% ==================
% Pnew: nova populacao de individuos (substituicao completa)

eta=1;

[N p]=size(X);

Xnew=[];
for i=1:N/2,
    
    I1=S(i,1);  % Indice da linha na matriz S correspondente ao pai
    I2=S(i,2);  % Indice da linha na matriz S correspondente a mae
    
    S1=X(I1,:);   % Encontra "potencial" pai na matriz S
    S2=X(I2,:);   % Encontra "potencial" mae na matriz S
    
    r=rand(1,p);
   
    i1=find(r<=0.5);
    i2=find(r>0.5);
    
    if isempty(i1),  % all random values > 0.5
      gama(i2) = (2*(1-r(i2))).^(-1/(eta+1));
    elseif isempty(i2), % all random values <= 0.5
      gama(i1) = (2*r(i1)).^(1/(eta+1));
    else 
       gama(i1) = (2*r(i1)).^(1/(eta+1));
       gama(i2) = (2*(1-r(i2))).^(-1/(eta+1));
    end
    
    Ip=ones(1,p); 
    if rand<=Pc,	   
    	    F1 = 0.5*[(Ip + gama).*S1 + (Ip - gama).*S2];   % 1st offspring
          
          Ilower=find(F1<limits(1));  % Genes abaixo do limite inferior
          Iupper=find(F1>limits(2));  % Genes acima do limite superior
          
          if !isempty(Ilower), F1(Ilower)=limits(1); end
          if !isempty(Iupper), F1(Iupper)=limits(2); end
          
          F2 = 0.5*[(Ip - gama).*S1 + (Ip + gama).*S2];   % 2nd offspring
          
          Ilower=find(F2<limits(1));  % Genes abaixo do limite inferior
          Iupper=find(F2>limits(2));  % Genes acima do limite superior
          
          if !isempty(Ilower), F2(Ilower)=limits(1); end
          if !isempty(Iupper), F2(Iupper)=limits(2); end
          
    else % Filhos=Pais se nao houver crossover 
    	    F1=S1;
    	    F2=S2;
    end
    
    Xnew=[Xnew;F1;F2];
end
    
