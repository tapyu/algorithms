function Xnew=mutacao2(X,pm,limits)
% Promove mutacao nos genes dos individuos da populacao P,
% com probabilidade de mutacao Pm

[N p]=size(X); % Dimensoes da matriz de populacao
%%% N=num.linhas=num.individuos
%%% p=num.colunas=num.genes

alfa=0.001;
xu=limits(2);
xl=limits(1);
for i=1:N,   % Indice para as linhas da matriz X (individuos)
    if rand < pm,
      X(i,:) = X(i,:) + alfa*(xu-xl).*randn(1,p);
      
      if X(i,:)<xl, X(i,:)=xl; end
      if X(i,:)>xu, X(i,:)=xu; end
    end
end

Xnew=X;