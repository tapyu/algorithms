% publish('script.m', 'pdf')
% publish('script.m', 'latex')