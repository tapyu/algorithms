function Xnew=mutacao3(X,pm,limits)
% Promove mutacao nos genes dos individuos da populacao P,
% com probabilidade de mutacao Pm

[N p]=size(X); % Dimensoes da matriz de populacao
%%% N=num.linhas=num.individuos
%%% p=num.colunas=num.genes

alfa=0.05;
Xu=[limits(2) limits(2)];
Xl=[limits(1) limits(1)];
for i=1:N,   % Indice para as linhas da matriz X (individuos)
    if rand < pm,
      X(i,:) = X(i,:) + alfa*(Xu-Xl).*randn(1,p);
    end
    
    Ilower=find(X(i,:)<limits(1));  % Genes abaixo do limite inferior
    Iupper=find(X(i,:)>limits(2));  % Genes acima do limite superior
          
    if !isempty(Ilower), X(i,Ilower)=limits(1); end
    if !isempty(Iupper), X(i,Iupper)=limits(2); end
end

Xnew=X;