function [Nacertos Nrej]=evalclassifier(Ytst,Ypred)

n=size(Ytst);

Ntst=n(2);

Nacertos=0;
Nrej=0;
for k=1:Ntst,
       % Paciente=k,
       % [Ypred(:,k) round(Ypred(:,k)) Ytst(:,k)],
                
        [~, Imax_pred]=max(Ypred(:,k));
        [~, Imax_real]=max(Ytst(:,k));
        
       % [Imax_pred Imax_real],
     
        Sy=round(sum(Ypred(:,k)));
        
        %pause
        
        if Sy != 1,
          Nrej=Nrej+1;
          %disp('')
          %disp('CLASSIFICACAO DO PACIENTE REJEITADA!!!!')
          %disp('')
        elseif Imax_pred == Imax_real,
           Nacertos=Nacertos+1;
        end
end
