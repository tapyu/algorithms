# ica2019.2
Homeworks da disciplina Inteligência Computacional Aplicada - TI0125

- HW 01: Data Preprocessing
- HW 02: Regression models
- HW 03: 

Para visualizar o notebook relativo ao HW01 segue o link: https://nbviewer.jupyter.org/github/ezequiasjunior/ica2019.2/blob/master/data_preprocessing.ipynb


Para visualizar os notebooks relativos ao HW02 (Parte 01 e 02) segue o link: https://nbviewer.jupyter.org/github/ezequiasjunior/ica2019.2/blob/master/Homework02/preprocessing_data_hw02.ipynb
