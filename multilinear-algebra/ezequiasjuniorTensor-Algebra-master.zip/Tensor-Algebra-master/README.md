# tensor-alg
Collection of Tensor Algebra homework.

Finished Homeroks on 26/06/20.

Implemented module functionality: partial.

TODOS: 

- Vector mode product - review
- TKPSVD.
