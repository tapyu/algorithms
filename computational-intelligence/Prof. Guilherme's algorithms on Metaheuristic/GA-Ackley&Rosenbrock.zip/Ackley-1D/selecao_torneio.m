function S=selecao_torneio(X,F);
% selecao de individuos pelo metodo do sorteio

[N p]=size(X);

S=[];
for i=1:N/2,

    % Seleciona 1o. individuo do par
    I=randperm(N);  % Numeros inteiros de 1 a n(1) em ordem aleatoria
    I1=I(1); I2=I(2); % Pega dois primeiros indices
    
    if F(I1) < F(I2), % Seleciona individuo de maior aptidao (problema de maximizacao)
    	Pai=I1;
    else
	    Pai=I2;
    end

    % Seleciona 2o. individuo do par
    I=randperm(N);  % Numeros inteiros de 1 a n(1) em ordem aleatoria
    I1=I(1); I2=I(2);  % Pega dois primeiros indices
    
    if F(I1) < F(I2), % Seleciona individuo de maior fitness
    	  Mae=I1;
    else
	      Mae=I2;
    end
        
    S=[S;Pai Mae];
end
    
