%% [TIP8419 - Algebra Linear e Multilinear] - Homework 13
% by Lucas Abdalah
% ----------------------------
% 
% hw13.m
% Author: Lucas Abdalah
%
