function F=avaliapop2(X)
% Calcula aptidao dos individuos da populacao P
% Entrada:
%    X - Matriz representando os individuos de uma geracao
%    nas linhas e os genes nas colunas
% Saida:
%    F - Valores correspondentes da funcao objetivo para os individuos 
%        da populacao X

[N p]=size(X);

for i=1:N,
    xi=X(i,:);
    F(i) = -20*exp(-0.2*abs(xi)) - exp(cos(2*pi*xi)) + 20 + exp(1);
end
F=F(:);