function Xnew=cruzamento2(X,S,Pc,limits);

% Cruzamento por 1 ponto de corte
% 
% Variaveis de entrada
% ====================
% P: populacao atual
% S: pares selecionados para POTENCIAL geracao de prole (cruzamento)
% Pc: probabilidade de recombinacao (crossover)
%
%
% Variaveis de saida
% ==================
% Pnew: nova populacao de individuos (substituicao completa)

eta=1;

[N p]=size(X);

Xnew=[];
for i=1:N/2,
    
    I1=S(i,1);  % Indice da linha na matriz S correspondente ao pai
    I2=S(i,2);  % Indice da linha na matriz S correspondente a mae
    
    S1=X(I1,:);   % Encontra "potencial" pai na matriz S
    S2=X(I2,:);   % Encontra "potencial" mae na matriz S
    
    r=rand(1,p);
   
    if r<=0.5,
       gama = (2*r)^(1/(eta+1));
    else 
       gama = (2*(1-r))^(-1/(eta+1));
    end
    
    Ip=ones(1,p);
    
    if rand<=Pc,	   
    	    F1 = 0.5*[(Ip + gama).*S1 + (Ip - gama)*S2];
          
          if F1<limits(1), F1=limits(1); end
          if F1>limits(2), F1=limits(2); end
          
          F2 = 0.5*[(Ip - gama).*S1 + (Ip + gama)*S2];
          
          if F2<limits(1), F2=limits(1); end
          if F2>limits(2), F2=limits(2); end
    else % Filhos=Pais se nao houver crossover 
    	    F1=S1;
    	    F2=S2;
    end
    
    Xnew=[Xnew;F1;F2];
end
    
