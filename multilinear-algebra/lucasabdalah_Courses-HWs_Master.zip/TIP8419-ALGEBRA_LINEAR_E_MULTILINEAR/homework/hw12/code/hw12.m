%% [TIP8419 - Algebra Linear e Multilinear] - Homework 12
% by Lucas Abdalah
% ----------------------------
% 
% hw12.m
% Author: Lucas Abdalah
%
