# Applied Computational Intelligence

## Homework 1 - (Finished)
### Intructions:
- To run this project please run the command below on a Julia REPL inside this folder

```include(hw1run.jl)```

- Some packages needs to be installed and this will throw an error asking you to ```add``` them.
- The report is at ```\hw1\report\hw1.pdf```.

## Homework 2 - (Finished)
- The same instructions are valid. In this homework the linear regression in this work.
