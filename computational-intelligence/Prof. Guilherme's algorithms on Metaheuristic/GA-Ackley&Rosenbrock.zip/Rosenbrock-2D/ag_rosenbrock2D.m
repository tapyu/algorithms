% Implementacao de um AG real para encontrar o minimo da
% funcao de Rosenbrock 2-D
%
%  f(x,y) = (1-x)^2 + 100*(y-x^2)^2, -5<=x,y<=5.
%
% Autor: Guilherme A. Barreto
% Data: 10/09/2020

clear; clc; close all;

%%% Parametros do AG
N=50;    % Tamanho da populacao
p=2;    % Tamanho do cromossomo (no. de genes)
pc=0.90;    % Probabilidade de cruzamento
pm=0.05; % Probabilidade de mutacao
Ng=100;   % Numero de geracoes

%%% Grafico da funcao a ser minimizada
xx=-5:0.1:5; yy=xx;
[XX,YY] = meshgrid(xx,yy);
ZZ = (1-XX).^2+100*(YY-XX.^2).^2;

%%% Geracao da populacao inicial
xl=-5;  xu=5;   % limites inferior/superior do espaco de busca 
X=unifrnd(xl,xu,N,p);

%%% Avaliacao da populacao inicial
F=avaliapop3(X);  % Retorna a aptidao de cada individuo da populacao

figure; contour(XX,YY,ZZ,20); hold on; plot(X(:,1),X(:,2),'*b','markersize',10); 
xlabel('X'); ylabel('Y'); grid; axis([-5 5 -5 5]);
set(gca, "fontsize", 14) 

%%% Roda AG por Ng geracoes
limits=[xl xu];
for t=1:Ng,
    geracao=t,
    S=selecao_torneio(X,F);
    X=cruzamento3(X,S,pc,limits);
    X=mutacao3(X,pm,limits);
    F=avaliapop3(X);
    
    [Fbest Ibest]=min(F);  % problema eh minimizacao
    [Fworst Iworst]=max(F);  
    
    solucao_best(t,:)=X(Ibest,:);
    solucao_worst(t,:)=X(Iworst,:);
    
    aptidao_best(t)=Fbest;
    aptidao_worst(t)=Fworst;
    
    if !mod(t,10),
      figure; contour(XX,YY,ZZ,20); hold on; 
      plot(X(:,1),X(:,2),'*b','markersize',10,solucao_best(t,1),solucao_best(t,2),'ro','linewidth',3,'markersize',10); 
      xlabel('X'); ylabel('Y'); grid; axis([-5 5 -5 5]); set(gca, "fontsize", 14) 
    end
    pause;
end

RESULTS=[solucao_best(end,:) aptidao_best(end)]

figure; 
%plot(1:Ng,aptidao_best,'b-','linewidth',3);
plot(1:Ng,aptidao_best,'b-','linewidth',3,1:Ng,aptidao_worst,'r-','linewidth',3);
xlabel('Geracao'); ylabel('APTIDAO'); grid; %axis([0 30 0 15]);
h = legend('Melhor solucao','Pior solucao');
set(h, "fontsize", 14);
set(gca, "fontsize", 14);