function F=avaliapop3(X)
% Calcula aptidao dos individuos da populacao P
% Entrada:
%    X - Matriz representando os individuos de uma geracao
%    nas linhas e os genes nas colunas
% Saida:
%    F - Valores correspondentes da funcao objetivo para os individuos 
%        da populacao X

[N p]=size(X);

for i=1:N,
    xi=X(i,1);
    yi=X(i,2);
    F(i) = (1-xi)^2+100*(yi-xi^2)^2;
end
F=F(:);